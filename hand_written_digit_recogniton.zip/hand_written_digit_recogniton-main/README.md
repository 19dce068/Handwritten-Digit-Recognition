# Hand Written digit recogintion

Hi

Welcome to this project


This is a simple website which will detect hindi and english digits with a pretty basic UI.
Hindi Dataset is DevanagariHandwrittenCharacterDataset
English Dataset is MNIST


Steps to install:
  - First, Download and Extract the zip file of this project
  - Next install virtualenv through command...

        pip install virtualenv

  - Create  a virtual enviornment with `virtualenv env`
  - In cmd then type, `env\Scripts\activate`
  - Then install all the requirements of this project by

        pip install -r requirements.txt
  - Then, `python manage.py migrate` and finally `python manage.py runserver` to run the server

  - Upload any single hindi / english image as is without resizing it'll work just fine.

  ## For any queries contact me through mail :
  `tanmay.damle.25@gmail.com`
